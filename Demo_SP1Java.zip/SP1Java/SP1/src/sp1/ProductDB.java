package sp1;


import com.mysql.jdbc.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;
import javax.swing.table.DefaultTableModel;
import sp1.DBUtil;


public class ProductDB {
    public static void loadData(DefaultTableModel model)
    {
        try {
            //khai bao chuoi ket noi
        String sql = "Select * from product";
        //mo ket noi
        Connection con = DBUtil.getConnection();
        //lay du lieu
        PreparedStatement ps = con.prepareCall(sql);
        //luu du lieu vao resultset
        ResultSet rs = ps.executeQuery();
        //doc du lieu tu resultset
        while(rs.next())
        {
            int productid = rs.getInt("id");
            String code = rs.getString("code");
            String des = rs.getString("description");
            double price = rs.getDouble("price");
            //tao datarow chud du lieu
            Vector dataRow = new Vector();
            dataRow.add(productid);
            dataRow.add(code);
            dataRow.add(des);
            dataRow.add(price);
            //dua vao model
            model.addRow(dataRow);
            
        }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
                
    }
}
