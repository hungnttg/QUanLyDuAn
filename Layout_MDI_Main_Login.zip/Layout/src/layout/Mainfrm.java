
package layout;

public class Mainfrm extends javax.swing.JFrame {

   
    public Mainfrm() {
        initComponents();
        quanlymn.setEnabled(false);
       
       
    }
    Loginfrm login;
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jDesktopPane1 = new javax.swing.JDesktopPane();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        loginmn = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        quanlymn = new javax.swing.JMenu();
        qldiemmn = new javax.swing.JMenuItem();
        qlthongtinmn = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout jDesktopPane1Layout = new javax.swing.GroupLayout(jDesktopPane1);
        jDesktopPane1.setLayout(jDesktopPane1Layout);
        jDesktopPane1Layout.setHorizontalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1226, Short.MAX_VALUE)
        );
        jDesktopPane1Layout.setVerticalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 898, Short.MAX_VALUE)
        );

        jMenu1.setText("Hệ thống");

        loginmn.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_L, java.awt.event.InputEvent.CTRL_MASK));
        loginmn.setText("Login");
        loginmn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginmnActionPerformed(evt);
            }
        });
        jMenu1.add(loginmn);

        jMenuItem2.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_E, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem2.setText("Exit");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem2);

        jMenuBar1.add(jMenu1);

        quanlymn.setText("Quản lý");

        qldiemmn.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_D, java.awt.event.InputEvent.CTRL_MASK));
        qldiemmn.setText("Quản lý điểm");
        qldiemmn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                qldiemmnActionPerformed(evt);
            }
        });
        quanlymn.add(qldiemmn);

        qlthongtinmn.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_T, java.awt.event.InputEvent.CTRL_MASK));
        qlthongtinmn.setText("Quản lý thông tin");
        qlthongtinmn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                qlthongtinmnActionPerformed(evt);
            }
        });
        quanlymn.add(qlthongtinmn);

        jMenuBar1.add(quanlymn);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jDesktopPane1, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jDesktopPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void loginmnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginmnActionPerformed
      if(login == null|| login.isClosed()){
          login = new Loginfrm();
          jDesktopPane1.add(login);
          
          login.setVisible(true);
          login.setLocation(400, 50);
         
          
      }else{
          login.setVisible(true);
      }
    }//GEN-LAST:event_loginmnActionPerformed

    private void qlthongtinmnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_qlthongtinmnActionPerformed
       
    }//GEN-LAST:event_qlthongtinmnActionPerformed

    private void qldiemmnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_qldiemmnActionPerformed
        
    }//GEN-LAST:event_qldiemmnActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
       System.exit(0);
    }//GEN-LAST:event_jMenuItem2ActionPerformed
  
 
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                Mainfrm jf = new Mainfrm();
                jf.setVisible(true);
                jf.setLocationRelativeTo(null);
                jf.setDefaultCloseOperation(Mainfrm.EXIT_ON_CLOSE);
                jf.setTitle("Hệ thống chính");
                
            }
        });
    }
    
   
    
   
    
  

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JDesktopPane jDesktopPane1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem loginmn;
    private javax.swing.JMenuItem qldiemmn;
    private javax.swing.JMenuItem qlthongtinmn;
    private javax.swing.JMenu quanlymn;
    // End of variables declaration//GEN-END:variables
}
