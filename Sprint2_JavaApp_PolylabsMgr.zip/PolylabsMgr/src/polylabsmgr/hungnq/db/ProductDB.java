/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polylabsmgr.hungnq.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import polylabsmgr.hungnq.business.Product;

/**
 *
 * @author mac
 */
public class ProductDB {
    //ham them san pham
    public static void add(Product p) throws Exception
    {
        //cau lenh insert
        String sql = "Insert into Product (Code,Description,ListPrice) values (?,?,?)";
        //tao ket noi
        Connection con = DBUtil.getConnection();//mo ket noi
        try {
            PreparedStatement ps = con.prepareStatement(sql);//chuan bi cau lenh
            //truyen gia tri vao tham so
            ps.setString(1, p.getCode());
            ps.setString(2, p.getDescription());
            ps.setDouble(3, p.getPrice());
            //thuc thi
            ps.executeUpdate();
            
        } catch (Exception e) {
        }
                
    }
    //lay toan bo san pham trong DB
    public static List<Product> getAll() throws Exception
    {
        String sql = "SELECT * FROM Product ORDER BY ProductID";
        List<Product> products = new ArrayList<>();
        Connection connection = DBUtil.getConnection();
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                int productID = rs.getInt("ProductID");
                String code = rs.getString("Code");
                String name = rs.getString("Description");
                double price = rs.getDouble("ListPrice");
                
                Product p = new Product();
                p.setId(productID);
                p.setCode(code);
                p.setDescription(name);
                p.setPrice(price);
                products.add(p);
            }
        } catch (Exception e) {
        }
        return products;
                
    }
    
}
