/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polylabsmgr.hungnq.db;

import com.mysql.jdbc.Connection;
import java.sql.DriverManager;

/**
 *
 * @author mac
 */
public class DBUtil {
    private static Connection connection;
    private DBUtil(){}
    //dinh nghia phuong thuc ket noi
    public static synchronized Connection getConnection() throws Exception
    {
        if(connection!=null)
        {
            return connection;
        }
        else
        {
            try {
                String url = "jdbc:mysql://localhost:3306/mma";
                String username="root";//root
                String password="";//""
                connection = (Connection) DriverManager.getConnection(url,username,password);
                return connection;
            } catch (Exception e) {
            }
        }
        return connection;
    }
    
    public static synchronized void closeConnection() throws Exception
    {
        if(connection!=null)
        {
            try {
                connection.close();
            } catch (Exception e) {
            }
            finally {
                connection=null;
            }
        }
    }
    
}
