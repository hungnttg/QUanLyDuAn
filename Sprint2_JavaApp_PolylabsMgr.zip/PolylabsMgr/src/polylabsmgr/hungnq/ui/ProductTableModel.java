/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polylabsmgr.hungnq.ui;

import java.util.List;
import javax.swing.table.AbstractTableModel;
import polylabsmgr.hungnq.business.Product;
import polylabsmgr.hungnq.db.ProductDB;

/**
 *
 * @author mac
 */
public class ProductTableModel extends AbstractTableModel{
    private List<Product> products;
    private static final String[] COLUMN_NAMES={"ProductID","Code","Description","Price"};
    //lay ve cac product tu DB dua vao list
    public ProductTableModel()
    {
        try {
            products = ProductDB.getAll();
        } catch (Exception e) {
        }
    }
    //lay ve 1 san pham tu JTable khi click vao Row tren JTable
    public Product getProduct(int rowIndex)
    {
        return products.get(rowIndex);
    }
    //cap nhat du lieu vao DB va JTable
    public void databaseUpdated()
    {
        try {
            products = ProductDB.getAll();
            fireTableDataChanged();
        } catch (Exception e) {
        }
    }

    @Override
    public int getRowCount() {
        return products.size();
    }

    @Override
    public int getColumnCount() {
        return COLUMN_NAMES.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch(columnIndex)
        {
            case 0:
                return products.get(rowIndex).getId();
            case 1:
                return products.get(rowIndex).getCode();
            case 2:
                return products.get(rowIndex).getDescription();
            case 3:
                return products.get(rowIndex).getPrice();
            default:
                return null;
                
        }
    }
    
}
