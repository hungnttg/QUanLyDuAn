/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package duan;

import java.util.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author win7
 */
public class DAO {
    //ham ket noi voi csdl
    public static Connection openConnection() throws ClassNotFoundException, SQLException
    {
        //khai bao chuoi ket noi csdl
        String connectionUrl
        ="jdbc:sqlserver://localhost:1433;databaseName=java;integratedSecurity=true";
        Connection con=null;//khoi tao ket noi
        //su dung driver cuar SqlServer
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        //tao ket noi
        con = DriverManager.getConnection(connectionUrl);
        //tra ve ket noi
        return con;
    }
    //viet ham load du lieu
    public static List loadData()
    {
         ArrayList<students> list = new ArrayList<>();//tao danh sach
        try {    
            //cau lenh lat du lieu
            String sql = "Select * from students order by masv";
            Connection con = DAO.openConnection();//mo ket noi
            Statement st = con.createStatement();
            //tao doi tuong chua du lieu va thuc thi lenh select
            ResultSet rs = st.executeQuery(sql);
            //cho vao vong lap de lay du lieuy
            while(rs.next())
            {
                //doc tung truong du lieu
                String masv = rs.getString(1);
                String hoten = rs.getString(2);
                String email = rs.getString(3);
                String sodt = rs.getString(4);
                boolean gioitinh = rs.getBoolean(5);
                String diachi = rs.getString(6);
                //dua tat ca vao doi tuong sv
                students sv = new students(masv,hoten, email, sodt,diachi,gioitinh);
                //them vao list
                list.add(sv);
            }
            con.close();//dong ket noi    
            return list;
        } 
        catch (ClassNotFoundException | SQLException ex ) 
        {
            Logger.getLogger(DAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
}
