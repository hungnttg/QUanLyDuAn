/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polylabs.hungnq.java.workshop42;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class NewJFrame extends javax.swing.JFrame {
    public void loadDataToJTable(DefaultTableModel model)
    {
        Connection connection = null;
        try {
            //1. khai bao chuoi ket noi CSDL
            String urlSQLServer= "jdbc:sqlserver://NVA\\SQLExpress:1433; databaseName=db1";
            String username ="sa";
            String password = "sa";
            /////
            String url = "jdbc:mysql://localhost:3306/mma";
            String u="root";
            String p="";
            //2. Mo ket noi
            connection = (Connection) DriverManager.getConnection(url,u,p);
            //3. khai bao chuoi truy van
            String sql = "Select * from product";
            //4. Chuan bi lenh doc du lieu
            PreparedStatement ps = (PreparedStatement) connection.prepareStatement(sql);
            //5. Thực thi truy vấn và lưu dữ liệu vào ResultSet
            ResultSet rs = ps.executeQuery();
            //6. đọc dữ liệu từ result và đưa vào model
            while(rs.next()){
                //6.1 doc (lay các trường dữ liệu
                int ProductID = rs.getInt("ProductID");
                String Code = rs.getString("Code");
                String Description = rs.getString("Description");
                double ListPrice = rs.getDouble("ListPrice");
                //6.2 dua du lieu vao vec to
                Vector v = new Vector();//ghép lại thành 1 dòng dữ liệu
                v.add(ProductID);
                v.add(Code);
                v.add(Description);
                v.add(ListPrice);
                //6.3 đưa vector vào model
                model.addRow(v);
            }
            
        } catch (Exception e) {
        }
    }
   
  public void updateRowOfModelToDatabase(JTable table, int row) 
    { 
       DefaultTableModel dtm = (DefaultTableModel)table.getModel(); 
       Vector data = dtm.getDataVector(); 
       Vector data2 = (Vector)data.get(row); 
       data2.clear(); 
       //data2.add("changed data1"); 
       //data2.add("changed data2"); 
       dtm.fireTableDataChanged(); 
       table.repaint(); 
       table.setModel(dtm); 
    }
  public void updateModelToDatabase()
  {
       Connection con =null;
       PreparedStatement ps;
      try {
                    String url = "jdbc:mysql://localhost:3306/mma";
                    String u="root";
                    String p="";
                    //2. Mo ket noi
                    con = (Connection) DriverManager.getConnection(url,u,p);
      } catch (Exception e) {
      }
      DefaultTableModel model = (DefaultTableModel) jTable1.getModel();

        String sd0 = null;
        for (int i = 1; i < model.getColumnCount(); i++) {
            //  System.out.println(dtm01.getColumnName(1));
            for (int j = 0; j < model.getRowCount(); j++) {
                try {
                    sd0 = model.getValueAt(j, i).toString();
                    String sql = "update product set "+model.getColumnName(i)+"='"+sd0+"' where ProductID='"+model.getValueAt(j, 0).toString()+"'";                  
                    ps = (PreparedStatement) con.prepareStatement(sql);
                   int kq= ps.executeUpdate();
                } catch (SQLException ex) {
                    // Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
                }

            }

        }
  }
  
  public void deleteRowFromDatabase(int id)
  {
      Connection con =null;
      PreparedStatement ps;
      try {
                    String url = "jdbc:mysql://localhost:3306/mma";
                    String u="root";
                    String p="";
                    //2. Mo ket noi
                    con = (Connection) DriverManager.getConnection(url,u,p);
      } catch (Exception e) {
      }
      
      try {
          String sql = "delete from product where productid=?";
            ps = (PreparedStatement) con.prepareStatement(sql);
            ps.setInt(1,Integer.parseInt(txtMaSP.getText().toString()));
           int kq= ps.executeUpdate();
           String a="";
      } catch (Exception e) {
      }
  }
  public void insertRowToDatabase()
  {
      Connection con =null;
      PreparedStatement ps;
      try {
                    String url = "jdbc:mysql://localhost:3306/mma";
                    String u="root";
                    String p="";
                    //2. Mo ket noi
                    con = (Connection) DriverManager.getConnection(url,u,p);
      } catch (Exception e) {
      }
      
      try {
          String sql = "INSERT INTO Product (Code, Description, ListPrice)"+
                " VALUES (?,?,?)";
            ps = (PreparedStatement) con.prepareStatement(sql);
            ps.setString(1, txtTenSP.getText().toString());
            ps.setString(2, cbxDVT.getSelectedItem().toString());
            ps.setDouble(3, Double.parseDouble(txtDonGia.getText().toString()));
           int kq =  ps.executeUpdate();
      } catch (Exception e) {
      }
  }
  public void updateRowToDatabase(int id)
  {
      Connection con =null;
      PreparedStatement ps;
      try {
                    String url = "jdbc:mysql://localhost:3306/mma";
                    String u="root";
                    String p="";
                    //2. Mo ket noi
                    con = (Connection) DriverManager.getConnection(url,u,p);
      } catch (Exception e) {
      }
      
      try {
          String sql = "update product set code=?, description=?, listprice=? where productid=?";
            ps = (PreparedStatement) con.prepareStatement(sql);
            ps.setString(1, txtTenSP.getText().toString());
            ps.setString(2, cbxDVT.getSelectedItem().toString());
            ps.setDouble(3, Double.parseDouble(txtDonGia.getText().toString()));
            ps.setInt(4,Integer.parseInt(txtMaSP.getText().toString()));
            ps.executeUpdate();
      } catch (Exception e) {
      }
  }
  

    DefaultTableModel model;
    public NewJFrame() {
        initComponents();
        String[] headers = {"ProductID","Code","Description","ListPrice","NCC"};
        String[][] data = {
            {"SP1","San pham 1","Kg","5000","AAA"},
            {"SP2","San pham 2","Thung","600","BB"},
            {"SP3","San pham 3","Kg","1000","CCCC"},
        
        };
        ///////////////////doc du lieu dummy
       // model = new DefaultTableModel(data,headers);//1.gắn dữ liệu vào model
        //jTable1.setModel(model);//2.đưa dữ liệu từ model-> jTable
         ///////////////////doc du lieu tu database
        model = new DefaultTableModel(headers,0);//1.gắn dữ liệu vào model
        loadDataToJTable(model);//2.doc du lieu tu database -> model
        jTable1.setModel(model);//3.đưa dữ liệu từ model-> jTable    
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtMaSP = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txtTenSP = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        cbxDVT = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        txtDonGia = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtNCC = new javax.swing.JTextField();
        btnInsertDB = new javax.swing.JButton();
        btnThem = new javax.swing.JButton();
        btnSua = new javax.swing.JButton();
        btnXoa = new javax.swing.JButton();
        btnUpdateDB = new javax.swing.JButton();
        btnDeleteDB = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 243, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(19, Short.MAX_VALUE))
        );

        jLabel1.setText("MaSP");

        jLabel2.setText("Ten SP");

        jLabel3.setText("DVT");

        cbxDVT.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Chai", "Thung", "Kg", "Lon" }));

        jLabel4.setText("Don gia");

        jLabel5.setText("NCC");

        btnInsertDB.setText("InsertDB");
        btnInsertDB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInsertDBActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtMaSP, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtTenSP, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(cbxDVT, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 77, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtDonGia, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtNCC, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(37, 37, 37))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnInsertDB)
                .addGap(60, 60, 60))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(txtMaSP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(17, 17, 17)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txtTenSP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(txtDonGia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(17, 17, 17)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(txtNCC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(cbxDVT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnInsertDB)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        btnThem.setText("Them");
        btnThem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemActionPerformed(evt);
            }
        });

        btnSua.setText("Sua");
        btnSua.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuaActionPerformed(evt);
            }
        });

        btnXoa.setText("Xoa");
        btnXoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaActionPerformed(evt);
            }
        });

        btnUpdateDB.setText("UpdateDB");
        btnUpdateDB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateDBActionPerformed(evt);
            }
        });

        btnDeleteDB.setText("DeleteDB");
        btnDeleteDB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteDBActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(27, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())))
            .addGroup(layout.createSequentialGroup()
                .addGap(69, 69, 69)
                .addComponent(btnThem)
                .addGap(35, 35, 35)
                .addComponent(btnSua)
                .addGap(34, 34, 34)
                .addComponent(btnXoa)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnUpdateDB)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnDeleteDB)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnThem)
                    .addComponent(btnSua)
                    .addComponent(btnXoa)
                    .addComponent(btnUpdateDB)
                    .addComponent(btnDeleteDB))
                .addContainerGap(8, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnThemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemActionPerformed
        //1. Tao vector và đưa dữ liệu vào vector
        Vector v = new Vector();
        v.add(txtMaSP.getText().trim());
        v.add(txtTenSP.getText().trim());
        v.add(cbxDVT.getSelectedItem());
        v.add(txtDonGia.getText().trim());
        v.add(txtNCC.getText().trim());
        //2. đưa vector vào model
        model.addRow(v);
    }//GEN-LAST:event_btnThemActionPerformed
        int row =0;
    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        //khi người dùng click vào jTable -> dữ liệu dòng phải hiển thị lên textbox
        //1. lấy chỉ số dòng
        row = jTable1.getSelectedRow();
        if(row<0) return;
        txtMaSP.setText(jTable1.getValueAt(row, 0).toString());
        txtTenSP.setText(jTable1.getValueAt(row, 1).toString());
        cbxDVT.setSelectedItem(jTable1.getValueAt(row, 2).toString());
        txtDonGia.setText(jTable1.getValueAt(row, 3).toString());
        txtNCC.setText(jTable1.getValueAt(row, 4).toString());
        
    }//GEN-LAST:event_jTable1MouseClicked

    private void btnXoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaActionPerformed
            //1. lấy dòng
            int row = jTable1.getSelectedRow();
            if(row<0){
                JOptionPane.showMessageDialog(this, "Chua chon dong");
                return;
            }
            //2. remove dong khoi model
            model.removeRow(row);
            
           
            
        
        
    }//GEN-LAST:event_btnXoaActionPerformed

    private void btnSuaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSuaActionPerformed
       //1. lay dong cần sửa
       int row = jTable1.getSelectedRow();
       //nếu chưa lấy được dòng thì đưa ra thông báo
       if(row<0)
       {
           JOptionPane.showMessageDialog(this, "Chua chon dong");
       }
       //2. đưa dữ liệu vào model
       model.setValueAt(txtTenSP.getText().toString(), row, 1);
       model.setValueAt(cbxDVT.getSelectedItem(), row, 2);
       model.setValueAt(txtDonGia.getText().toString(), row, 3);
       model.setValueAt(txtNCC.getText().toString(), row, 4);
       
      
     
    }//GEN-LAST:event_btnSuaActionPerformed

    private void btnUpdateDBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateDBActionPerformed
           //updateModelToDatabase();
           updateRowToDatabase(row);
                
    }//GEN-LAST:event_btnUpdateDBActionPerformed

    private void btnDeleteDBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteDBActionPerformed
        // TODO add your handling code here:
        deleteRowFromDatabase(row);
    }//GEN-LAST:event_btnDeleteDBActionPerformed

    private void btnInsertDBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInsertDBActionPerformed
        // TODO add your handling code here:
        insertRowToDatabase();
    }//GEN-LAST:event_btnInsertDBActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new NewJFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnDeleteDB;
    private javax.swing.JButton btnInsertDB;
    private javax.swing.JButton btnSua;
    private javax.swing.JButton btnThem;
    private javax.swing.JButton btnUpdateDB;
    private javax.swing.JButton btnXoa;
    private javax.swing.JComboBox<String> cbxDVT;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField txtDonGia;
    private javax.swing.JTextField txtMaSP;
    private javax.swing.JTextField txtNCC;
    private javax.swing.JTextField txtTenSP;
    // End of variables declaration//GEN-END:variables
}
