
package duan2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class DAO {
    //dinh nghia ham ket noi voi csdl
    public static Connection openConnection() throws ClassNotFoundException, SQLException
    {
        //chuoi ket noi
        String sql
       ="jdbc:sqlserver://localhost:1433;databaseName=java;integratedSecurity=true";
        //su dung driver
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        //tao ket noi
        Connection con = DriverManager.getConnection(sql);
        //tra ve ket qua
        return con;
        
                
    }
    public static List loadData()
    {
        List<students> list = new ArrayList<>();
        try {
            String sql = "Select * from students";
            Connection con = DAO.openConnection();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
                String masv = rs.getString(1);
                String hoten = rs.getString(2);
                String email = rs.getString(3);
                String sodt = rs.getString(4);
                boolean gioitinh = rs.getBoolean(5);
                String diachi = rs.getString(6);
                students sv = new students(masv, hoten, email, sodt,diachi,gioitinh);
                list.add(sv);
            }
            con.close();
            return list;
        } catch (Exception e) {
        }
        return null;
    }
}
