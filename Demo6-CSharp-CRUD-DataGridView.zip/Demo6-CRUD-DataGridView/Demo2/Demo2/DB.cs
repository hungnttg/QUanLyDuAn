﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace Demo2
{
    public class DB
    {
        SqlConnection conn;
        SqlCommand com;
        SqlDataAdapter da;
        DataSet ds;
        public void ketnoi()
        {
            string s = "Data Source=.; Initial Catalog=SachDB; Integrated Security=True";
            conn = new SqlConnection(s);
            da = new SqlDataAdapter();
            ds = new DataSet();
        }
        public void getData(ListView lv)
        {
            com = new SqlCommand("SELECT * FROM products", conn);
            da.SelectCommand = com;
            da.Fill(ds, "Products");
            lv.Items.Clear();
            for (int rows = 0; rows < ds.Tables[0].Rows.Count; rows++)
            {
                lv.Items.Add(ds.Tables[0].Rows[rows].ItemArray[0].ToString());
                lv.Items[rows].SubItems.Add(ds.Tables[0].Rows[rows].ItemArray[1].ToString());
                lv.Items[rows].SubItems.Add(ds.Tables[0].Rows[rows].ItemArray[2].ToString());
                lv.Items[rows].SubItems.Add(ds.Tables[0].Rows[rows].ItemArray[3].ToString());
            }
        }
        //ham them san pham
        public void saveData(TextBox txtMaSach, TextBox txtTieuDe, 
            TextBox txtGia, TextBox txtSoLuong)
        { 
            //lay du lieu tren form va cap nhat vao dataset (bo nho dem nam giua giao dien va csdl)
            ds.Tables["Products"].Rows.Add(txtMaSach.Text,txtTieuDe.Text,
                Convert.ToDecimal(txtGia.Text),Convert.ToInt32(txtSoLuong.Text));
            SqlCommandBuilder cb = new SqlCommandBuilder(da);//chuan bi lenh
            cb.GetInsertCommand();//thuc hien lenh insert
            da.Update(ds, "Products");//sau khi insert, cap nhat vao dataset
        }
        //sp3.1 - ham hien thi du lieu len textbox
        //khi click vao listview-> hien thi du lieu len textbox
        public void getDataToTextBox(TextBox txtMaSach, TextBox txtTieuDe,
            TextBox txtGia, TextBox txtSoLuong, ListView lv)
        { 
            //1. Lay ve chi so dong vua click
            int index = lv.SelectedItems[0].Index;
            //2. Tao doi tuong DataRow de chua du lieu cua dong vua click
            DataRow dr = ds.Tables["Products"].Rows[index];
            //3. Gan du lieu len textbox
            txtMaSach.Text = dr[0].ToString();
            txtTieuDe.Text = dr[1].ToString();
            txtGia.Text = dr[2].ToString();
            txtSoLuong.Text = dr[3].ToString();
        }
        //sp3.2 Cap nhat du lieu
        int selectedIndex;
        public void updateData(TextBox txtMaSach, TextBox txtTieuDe,
            TextBox txtGia, TextBox txtSoLuong, ListView lv)
        { 
            //1. Gan chi so cho dong vua chon
            selectedIndex = lv.SelectedItems[0].Index;
            //2. lay du lieu tu TextBox dua vao dataset
            ds.Tables["Products"].Rows[selectedIndex][1] = txtTieuDe.Text;
            ds.Tables["Products"].Rows[selectedIndex][2] = txtGia.Text;
            ds.Tables["Products"].Rows[selectedIndex][3] = txtSoLuong.Text;
            //3. su dung doi tuong chua du lieu va update
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            cb.GetUpdateCommand();
            da.Update(ds, "Products");
            

        }

    }
}
