﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Demo2
{
    public partial class Form2 : Form
    {
        SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=SachDB;Integrated Security=true;");
        SqlCommand cmd;
        SqlDataAdapter adapt;
        //ID variable used in Updating and Deleting Record  
        string ID = "";  
        public Form2()
        {
            InitializeComponent();
            DisplayData(); 
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
        //Display Data in DataGridView  
        private void DisplayData()
        {
            con.Open();
            DataTable dt = new DataTable();
            adapt = new SqlDataAdapter("select * from products", con);
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }
        //Clear Data  
        private void ClearData()
        {
            txtMaSach.Text = "";
            txtTieuDe.Text = "";
            txtGiamGia.Text = "";
            txtSoLuong.Text = "";
            ID = "";
        }  

        private void btnInsert_Click(object sender, EventArgs e)
        {
            if (txtMaSach.Text != "" && txtTieuDe.Text != "" && txtGiamGia.Text != "" && txtSoLuong.Text != "")
            {
                cmd = new SqlCommand("insert into Products(ProductCode,Description,UnitPrice,OnHandQuantity) values(@ProductCode,@Description,@UnitPrice,@OnHandQuantity)", con);
                con.Open();
                cmd.Parameters.AddWithValue("@ProductCode", txtMaSach.Text);
                cmd.Parameters.AddWithValue("@Description", txtTieuDe.Text);
                cmd.Parameters.AddWithValue("@UnitPrice", txtGiamGia.Text);
                cmd.Parameters.AddWithValue("@OnHandQuantity", txtSoLuong.Text);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Record Inserted Successfully");
                DisplayData();
                ClearData();
            }
            else
            {
                MessageBox.Show("Please Provide Details!");
            }  
        }

        private void Update_Click(object sender, EventArgs e)
        {
            if (txtMaSach.Text != "" && txtTieuDe.Text != "" && txtGiamGia.Text != "" && txtSoLuong.Text != "")
            {

                cmd = new SqlCommand("update products set Description=@Description,UnitPrice=@UnitPrice,OnHandQuantity=@OnHandQuantity where ProductCode=@ProductCode", con);
                con.Open();
                cmd.Parameters.AddWithValue("@ProductCode", txtMaSach.Text);
                cmd.Parameters.AddWithValue("@Description", txtTieuDe.Text);
                cmd.Parameters.AddWithValue("@UnitPrice", txtGiamGia.Text);
                cmd.Parameters.AddWithValue("@OnHandQuantity", txtSoLuong.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record Updated Successfully");
                con.Close();
                DisplayData();
                ClearData();
                 
            }
            else
            {
                MessageBox.Show("Please Select Record to Update");
            }  
        }

        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            ID = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
            txtMaSach.Text = ID;
            txtTieuDe.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            txtGiamGia.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            txtSoLuong.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();  
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (ID != "")
            {
                cmd = new SqlCommand("delete products where ProductCode=@ProductCode", con);
                con.Open();
                cmd.Parameters.AddWithValue("@ProductCode", txtMaSach.Text);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Record Deleted Successfully!");
                DisplayData();
                ClearData();
            }
            else
            {
                MessageBox.Show("Please Select Record to Delete");
            }  
        }  
    }
}
