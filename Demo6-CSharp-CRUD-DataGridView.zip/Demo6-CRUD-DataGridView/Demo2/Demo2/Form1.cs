﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Demo2
{
    public partial class Form1 : Form
    {
        DB db = new DB();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            db.ketnoi();
            db.getData(listView1);
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            db.saveData(txtMaSach, txtTieuDe, txtGia, txtSoLuong);
            Form1_Load(null, null);//goi lai su kien (su dung delegate)

            MessageBox.Show("Insert thanh cong", "Thong bao");
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listView1_Click(object sender, EventArgs e)
        {
            db.getDataToTextBox(txtMaSach, txtTieuDe, txtGia, txtSoLuong, listView1);
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            db.updateData(txtMaSach, txtTieuDe, txtGia, txtSoLuong, listView1);
            Form1_Load(null, null);//goi lai su kien (su dung delegate)
        }

        
    }
}
