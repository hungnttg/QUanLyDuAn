
package javaapplication2;

import com.mysql.jdbc.Connection;
import java.sql.DriverManager;

public class DBUtil {
    private static Connection connection;

    public DBUtil() {
    }
    //ham ket noi
    public static synchronized Connection getConnection()
    {
        if(connection!=null)
        {
            return connection;
        }
        else
        {
            try {
                String url ="jdbc:mysql://localhost:3306/SP1";
                String u = "root";
                String p="";
                connection = (Connection) DriverManager.getConnection(url,u,p);
                return connection;          
                } catch (Exception e) 
                {
                    e.printStackTrace();
                }
            
        }
        return null;
    }
    //dong ket noi
    public static synchronized void closeConnection()
    {
        if(connection!=null)
        {
            try {
                connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            finally
            {
                connection=null;
            }
        }
        
        
    }
}
