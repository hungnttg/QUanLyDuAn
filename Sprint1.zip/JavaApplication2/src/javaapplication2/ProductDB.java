
package javaapplication2;

import com.mysql.jdbc.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;
import javax.swing.table.DefaultTableModel;

public class ProductDB {
    public static void loadData(DefaultTableModel model)
    {
        try {
            //khai bao chuoi truy van
            String sql = "Select * from product";
            //mo ket noi
            Connection con = DBUtil.getConnection();
            //chuan bij lenh doc du lieu
            PreparedStatement ps = con.prepareStatement(sql);
            //thuc thi cau lenh va tra ve resultset
            ResultSet rs = ps.executeQuery();
            //doc du lieu trong rs
            while(rs.next())
            {
                //doc
                int producId = rs.getInt("id");
                String code =rs.getString("code");
                String des = rs.getString("description");
                double price = rs.getDouble("price");
                //chuyen vao vector
                Vector v = new Vector();
                v.add(producId);
                v.add(code);
                v.add(des);
                v.add(price);
                //dua vao model
                model.addRow(v);                      
            }
        } catch (Exception e) {
        }
    }
}
